"""
Purpose:
--------
Starts the GDELT ETL pipeline and launches the monitoring process.

This module represents the entry point of the ETL pipeline.
"""






'''# Import the function that reads the last processed timestamp.
from checkpoint import read_checkpoint'''

'''# Import the function that downloads any missed datasets.
from historical import historical_backfill'''

# Import the function that retrieves the latest GDELT file URLs.
from latest_file import get_latest_files

# Import the function that continuously monitors GDELT for new files.
from monitor import monitor
# importing the logging configuration
#import logging 
import logging_config 



# logging.info("Pipeline started.")

# Main function that controls the pipeline workflow.
def main():

    # Display a message indicating that the pipeline has started.
    print("===== GDELT PIPELINE STARTED =====")

    '''# Read the last successfully processed timestamp.
    checkpoint = read_checkpoint()'

    # If a checkpoint exists, recover any missed datasets.
    if checkpoint:

        # Retrieve the latest available GDELT files.
        current = get_latest_files()

        # Extract the timestamp from the latest file URL.
        latest_timestamp = (
            list(current.values())[0]
            .split("/")[-1]
            .split(".")[0]
        )

        # Download and process any missing datasets.
        historical_backfill(
            checkpoint,
            latest_timestamp
            )'''
        
    # Start monitoring GDELT for newly published files.
    monitor()


# Run the pipeline when this file is executed directly.
if __name__ == "__main__":
    main()
    '''
Acts as the main entry point of the application, 
coordinating the execution of the entire ingestion pipeline.
---------------------
why?
Provides a single script to run the pipeline 
and orchestrates the interaction between all the modules.
'''