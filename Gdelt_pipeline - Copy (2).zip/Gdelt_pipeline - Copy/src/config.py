"""
Purpose:
--------
Stores all configuration values used throughout the GDELT ingestion pipeline.

This includes:
- GDELT URLs
- Local folder locations
- Request timeout

This module centralizes the project's configuration.

"""

from pathlib import Path

# ==========================================================
# GDELT SERVER CONFIGURATION
# ==========================================================

# Base URL of the GDELT data repository.
BASE_URL = "http://data.gdeltproject.org/gdeltv2/"

# URL used to retrieve the latest published datasets.
LAST_UPDATE_URL = BASE_URL + "lastupdate.txt"

# ==========================================================
# LOCAL FOLDER STRUCTURE
# ==========================================================

# Main data folder.
DATA_FOLDER = Path("data")
DATA_FOLDER.mkdir(exist_ok=True)

# Stores the original ZIP files downloaded from GDELT.
RAW_DATA_FOLDER = DATA_FOLDER / "raw"
RAW_DATA_FOLDER.mkdir(parents=True, exist_ok=True)

# Stores the extracted CSV files.
EXTRACTED_DATA_FOLDER = DATA_FOLDER / "extracted"
EXTRACTED_DATA_FOLDER.mkdir(parents=True, exist_ok=True)

# Stores cleaned or transformed datasets.
PROCESSED_DATA_FOLDER = DATA_FOLDER / "processed"
PROCESSED_DATA_FOLDER.mkdir(parents=True, exist_ok=True)

# Stores application log files.
LOG_FOLDER = Path("logs")
LOG_FOLDER.mkdir(exist_ok=True)

# ==========================================================
# REQUEST CONFIGURATION
# ==========================================================

# Maximum time (seconds) to wait for a response from GDELT.
REQUEST_TIMEOUT = 60

'''
Stores all the configuration settings used by the pipeline, 
such as the GDELT server URL, local data folders, 
log folder, and request timeout.
---------------
why?
Centralizing configuration makes the pipeline easier 
to maintain because settings only need to be changed in one place 
rather than throughout the code.
'''