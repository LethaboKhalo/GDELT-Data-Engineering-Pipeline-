"""
Purpose:
--------
Extracts downloaded GDELT ZIP files and saves the extracted CSV files
into the extracted data folder.

This module represents the extraction stage of the ETL pipeline.
"""

# Library used to work with ZIP archives.
import zipfile

# Import the folder locations from the configuration file.
from config import RAW_DATA_FOLDER, EXTRACTED_DATA_FOLDER


def extract_zip(zip_path):
    """
    Extracts a downloaded GDELT ZIP file.

    Parameters
    ----------
    zip_path : pathlib.Path
        Path to the downloaded ZIP file.

    Returns
    -------
    pathlib.Path
        Path to the extracted CSV file.
    """

    # Display which ZIP file is currently being extracted.
    print(f"\nExtracting: {zip_path}")

    # Open the ZIP archive in read mode.
    with zipfile.ZipFile(zip_path, "r") as zip_ref:

        # Get a list of all files contained inside the ZIP archive.
        files = zip_ref.namelist()

        # Display the contents of the ZIP archive.
        print(files)

        # Store the name of the first file.
        # GDELT ZIP files contain a single CSV file.
        first_file = files[0]

        # Extract the CSV file into the extracted data folder.
        zip_ref.extractall(EXTRACTED_DATA_FOLDER)

    # Build the full path to the extracted CSV file.
    csv_path = EXTRACTED_DATA_FOLDER / first_file

    # Display where the CSV file was extracted.
    print(f"Extracted to: {csv_path}")

    # Return the path to the extracted CSV file.
    return csv_path
'''
Extracts the downloaded ZIP files and
returns the path to the extracted CSV file.
-----------------------------
why?
Isolates the extraction process 
so that compressed files can be handled consistently before loading the data.
'''