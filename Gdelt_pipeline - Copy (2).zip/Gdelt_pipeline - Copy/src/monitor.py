"""
Purpose:
--------
Continuously monitors GDELT for newly published datasets every
15 minutes and processes new files when they become available.

This module represents the orchestration stage of the ETL pipeline.
"""


# Import the time module to pause the pipeline between checks.
import time

# Import the function that retrieves the latest GDELT file URLs.
from latest_file import get_latest_files

# Import the function that downloads and processes each dataset.
from processor import process_dataset

# Store the URLs of files that have already been processed.
processed_files = set()


# Continuously monitor GDELT for newly published datasets.
def monitor():

    # Keep the pipeline running indefinitely.
    while True:

        # Display a status message.
        print("=" * 60)
        print("Checking for new GDELT files...")
        print("=" * 60)

        # Retrieve the latest Events, Mentions and GKG file URLs.
        latest_files = get_latest_files()

        # Loop through each available dataset.
        for dataset, file_url in latest_files.items():

            # Process the file only if it hasn't been processed before.
            if file_url not in processed_files:

                # Download, extract and load the dataset.
                process_dataset(dataset, file_url)

                # Record the file so it isn't processed again.
                processed_files.add(file_url)

            else:

                # Notify the user that the file has already been processed.
                print(f"{dataset} already processed.")

        print("\nWaiting for the next check...\n")

        # Countdown timer (15 minutes = 900 seconds)
        for remaining in range(900, 0, -1):

            minutes = remaining // 60
            seconds = remaining % 60

            print(
                f"\rNext check in: {minutes:02d}:{seconds:02d}",
                end="",
                flush=True
            )

            time.sleep(1)

        # Move to the next line after the countdown finishes.
        print()
'''
        Continuously monitors GDELT for newly published datasets 
        and processes any files that have not yet been downloaded.
        -----------------
        why?
        Enables automated ingestion by checking for 
        new data at regular intervals (e.g., every 15 minutes).
        '''