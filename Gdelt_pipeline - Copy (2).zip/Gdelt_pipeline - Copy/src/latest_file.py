"""
Purpose:
--------
Retrieves the latest available GDELT dataset URLs by reading
the GDELT lastupdate.txt file.

This module identifies the newest datasets to be processed.
"""



# Import the requests library to send HTTP requests.
import requests

# Import the URL that contains the latest GDELT file information.
from config import LAST_UPDATE_URL


# Retrieve the latest available GDELT dataset URLs.
def get_latest_files():

    # Send a request to the GDELT lastupdate.txt endpoint.
    response = requests.get(LAST_UPDATE_URL)

    # Raise an exception if the request was unsuccessful.
    response.raise_for_status()

    # Dictionary to store the latest file URL for each dataset.
    latest_files = {}

    # Loop through each line in the lastupdate.txt file.
    for line in response.text.splitlines():

        # Extract the file URL from the current line.
        filename = line.split()[-1]

        # Store the latest Events dataset URL.
        if ".export.CSV.zip" in filename:
            latest_files["events"] = filename

        # Store the latest Mentions dataset URL.
        elif ".mentions.CSV.zip" in filename:
            latest_files["mentions"] = filename

        # Store the latest GKG dataset URL.
        elif ".gkg.csv.zip" in filename:
            latest_files["gkg"] = filename

    # Return the dictionary containing the latest dataset URLs.
    return latest_files

'''
Connects to GDELT's lastupdate.txt endpoint to discover the latest Events,
Mentions, and GKG datasets available for download.
------------------------------
why?
Eliminates the need to hardcode filenames, allowing the pipeline 
to automatically detect newly published datasets.
'''