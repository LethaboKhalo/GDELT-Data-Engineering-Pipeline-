"""
Purpose:
--------
Loads the extracted CSV files into pandas DataFrames, applies
the correct GDELT column headers and saves the data as Parquet files.

This module represents the Transform stage of the ETL pipeline.
"""


import pandas as pd

from headers import (
    EVENT_HEADERS,
    MENTION_HEADERS,
    GKG_HEADERS
)


# Load an extracted GDELT file into a pandas DataFrame.
def load_data(csv_path, dataset):

    # Display the file currently being loaded.
    print(f"\nLoading: {csv_path}")

    # Select the correct column headers based on the dataset.
    if dataset == "events":
        headers = EVENT_HEADERS

    elif dataset == "mentions":
        headers = MENTION_HEADERS

    elif dataset == "gkg":
        headers = GKG_HEADERS

    else:
        raise ValueError(f"Unknown dataset: {dataset}")

    # Read the file into a DataFrame using the selected headers.
    df = pd.read_csv(
        csv_path,
        sep="\t",
        names=headers,
        header=None,
        encoding="latin-1",
        low_memory=False
    )

    # Return the DataFrame.
    return df

'''
Loads the extracted CSV file into a pandas DataFrame 
for analysis and further processing.
------------------------
why?
Provides a dedicated location for data loading 
and future data cleaning or transformation steps.
'''