"""
Purpose:
--------
Downloads GDELT ZIP files from the provided URL and stores them
locally in the raw data folder.

This module represents the Extract stage of the ETL pipeline.
"""

# Library used to send HTTP requests.
import requests

# Used to work with file paths.
from pathlib import Path

# Import the raw data folder location and request timeout.
from config import RAW_DATA_FOLDER, REQUEST_TIMEOUT


def download_file(file_url):
    """
    Downloads a ZIP file from GDELT.

    Parameters
    ----------
    file_url : str
        URL of the ZIP file to download.

    Returns
    -------
    pathlib.Path | None
        Path to the downloaded ZIP file if successful,
        otherwise None.
    """

    # Display which file is currently being downloaded.
    print("Using updated downloader.py")
    print(f"\nDownloading: {file_url}")

    
    file_name = Path(file_url).name

    # Create the full path where the ZIP file will be saved.
    save_path = RAW_DATA_FOLDER / file_name

    try:

        # Send an HTTP GET request to download the file.
        response = requests.get(
            file_url,
            timeout=REQUEST_TIMEOUT
        )

        # Raise an exception if the download fails.
        response.raise_for_status()

        # Open the destination file in binary write mode ("wb") and save the downloaded contents.
        with open(save_path, "wb") as file:
            file.write(response.content)

        # Display where the ZIP file was saved.
        print(f"Saved to: {save_path}")

        # Return the path to the downloaded ZIP file.
        return save_path

    # Handle the case where the file is not yet available.
    except requests.exceptions.HTTPError:

        print(f"File not available yet: {file_url}")

        return None

    # Handle other request errors such as connection or timeout issues.
    except requests.exceptions.RequestException as error:

        print(f"Download failed: {error}")

        return None

'''
Downloads ZIP files from the GDELT server
and saves them to the local data directory.
----------------------------
why?
Separates the downloading logic from the rest of the pipeline, 
making it easier to add features like retries, error handling, 
and download validation.
'''