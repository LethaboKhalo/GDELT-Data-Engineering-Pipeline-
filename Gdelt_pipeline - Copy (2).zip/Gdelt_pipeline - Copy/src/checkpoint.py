"""
Purpose:
--------
Stores and retrieves the timestamp of the last successfully
processed GDELT dataset.

This module supports pipeline recovery after interruptions.
"""







''' # Import the Path class for working with file paths.
from pathlib import Path

# Path to the file that stores the last processed timestamp.
CHECKPOINT_FILE = Path("checkpoint.txt")


# Read the last processed timestamp from the checkpoint file.
def read_checkpoint():

    # Return None if the checkpoint file does not exist.
    if not CHECKPOINT_FILE.exists():
        return None

    # Read and return the saved timestamp.
    return CHECKPOINT_FILE.read_text().strip()


# Save the latest processed timestamp to the checkpoint file.
def update_checkpoint(timestamp):

    # Write the timestamp to the checkpoint file.
    CHECKPOINT_FILE.write_text(timestamp)


# Extract the timestamp from a GDELT file URL or filename.
def extract_timestamp(file_url):

    # Extract the filename from the URL.
    filename = Path(file_url).name

    # Return only the timestamp portion of the filename.
    return filename.split(".")[0]'''