"""
Purpose:
--------
Coordinates the processing of each GDELT dataset by downloading,
extracting and transforming the data.

This module manages the ETL workflow for a single dataset.
"""







import logging 

# Import the function that downloads the ZIP file
from downloader import download_file

# Import the function that extracts the ZIP file
from extractor import extract_zip

# Import the function that loads the CSV into a DataFrame
from transform import load_data

# Import the folder where processed files will be stored
from config import PROCESSED_DATA_FOLDER


def process_dataset(dataset, file_url):

    # Display which dataset is being processed
    print(f"\nProcessing {dataset.upper()}")

    # Download the ZIP file
    zip_path = download_file(file_url)

 # Stop processing if the download failed.
    if zip_path is None:
     return None

    # Extract the ZIP file
    csv_path = extract_zip(zip_path)

    # Load the extracted CSV into a pandas DataFrame
    df = load_data(csv_path, dataset)
    logging.info(
    f"{dataset} processed successfully. "
    f"Rows: {df.shape[0]}, Columns: {df.shape[1]}"
)

    # Save the DataFrame as a Parquet file
    parquet_path = PROCESSED_DATA_FOLDER / f"{dataset}.parquet"
    df.to_parquet(parquet_path, index=False)

    # Display where the Parquet file was saved
    print(f"Processed data saved to: {parquet_path}")

    # Display the DataFrame dimensions
    print(df.shape)

    # Return the DataFrame
    return df

'''
Coordinates the core ETL workflow 
by downloading, extracting, and loading a single dataset.
------------------------
why?
Keeps the main processing logic in 
one reusable function that can be called by different parts of the pipeline.
'''