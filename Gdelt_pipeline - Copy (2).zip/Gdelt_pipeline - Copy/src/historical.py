"""
Purpose:
--------
Generates historical GDELT file URLs and processes datasets
that were missed while the pipeline was offline.

This module supports historical backfilling of GDELT data.
"""



'''# Import classes for working with dates and times.
from datetime import datetime, timedelta

# Import the function that downloads and processes a dataset.
from processor import process_dataset

# Import the GDELT base URL.
from config import BASE_URL


# Generate a list of 15-minute timestamps between two timestamps.
def generate_timestamps(start_timestamp, end_timestamp):

    # Convert the start timestamp into a datetime object.
    start = datetime.strptime(
        start_timestamp,
        "%Y%m%d%H%M%S"
    )

    # Convert the end timestamp into a datetime object.
    end = datetime.strptime(
        end_timestamp,
        "%Y%m%d%H%M%S"
    )

    # Store all generated timestamps.
    timestamps = []

    # Start from the next 15-minute interval.
    current = start + timedelta(minutes=15)

    # Continue generating timestamps until the end timestamp is reached.
    while current <= end:

        # Convert the datetime back into GDELT's timestamp format.
        timestamps.append(
            current.strftime("%Y%m%d%H%M%S")
        )

        # Move to the next 15-minute interval.
        current += timedelta(minutes=15)

    # Return the list of timestamps.
    return timestamps


# Build the GDELT file URLs for a specific timestamp.
def build_urls(timestamp):

    return {

        # URL for the Events dataset.
        "events":
            BASE_URL +
            f"{timestamp}.export.CSV.zip",

        # URL for the Mentions dataset.
        "mentions":
            BASE_URL +
            f"{timestamp}.mentions.CSV.zip",

        # URL for the GKG dataset.
        "gkg":
            BASE_URL +
            f"{timestamp}.gkg.csv.zip"

    }


# Download and process any datasets that were missed.
def historical_backfill(
        start_timestamp,
        end_timestamp
):

    # Generate all missing 15-minute timestamps.
    timestamps = generate_timestamps(
        start_timestamp,
        end_timestamp
    )

    # Process each missing timestamp.
    for timestamp in timestamps:

        # Display the timestamp currently being backfilled.
        print(f"\nBackfilling {timestamp}")

        # Build the dataset URLs for the current timestamp.
        urls = build_urls(timestamp)

        # Download and process each dataset.
        for dataset, file_url in urls.items():

            process_dataset(dataset, file_url)'''