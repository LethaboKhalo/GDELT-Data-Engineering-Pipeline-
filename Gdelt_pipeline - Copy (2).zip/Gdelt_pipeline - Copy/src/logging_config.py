"""
Purpose:
--------
Configures the logging system used throughout the pipeline to
record processing events, warnings and errors.

This module supports monitoring and troubleshooting.
"""




# Import Python's built-in logging module.
import logging

# Import the folder where log files will be stored.
from config import LOG_FOLDER


# Configure the application's logging settings.
logging.basicConfig(

    # Save log messages to the pipeline.log file.
    filename=LOG_FOLDER / "pipeline.log",

    # Record log messages with a severity level of INFO or higher.
    level=logging.INFO,

    # Define the format of each log entry.
    format="%(asctime)s | %(levelname)s | %(message)s"
)
'''
Configures the application's logging settings,
including log file location, format, and logging level.
-----------------
why?
Provides a consistent way to record pipeline events, warnings,
and errors for monitoring and debugging.
'''